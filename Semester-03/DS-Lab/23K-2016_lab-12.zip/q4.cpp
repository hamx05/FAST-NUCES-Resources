#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

void printTable(std::vector<int> &table, const std::string &tableName) {
    std::cout << tableName << ": ";
    for(int val : table) {
        std::cout << val << " ";
    }
    std::cout << std::endl;
}

void buildBadCharTable(const std::string &pattern, std::vector<int> &badCharTable) {
    badCharTable.assign(256, pattern.length());
    for(size_t i = 0; i < pattern.length() - 1; i++) {
        badCharTable[static_cast<unsigned char>(pattern[i])] = pattern.length() - i - 1;
    }
    printTable(badCharTable, "Bad Character Table");
}

void buildGoodSuffixTable(const std::string &pattern, std::vector<int> &goodSuffixTable) {
    int m = pattern.length();
    goodSuffixTable.resize(m + 1, m);

    for(int i = m - 1; i >= 0; i--) {
        int j = m - 1;
        while (j >= 0 && pattern.substr(i, m - i) == pattern.substr(m - (m - i), m - i)) {
            j -= (m - i);
        }
        goodSuffixTable[i] = j + 1;
    }
    printTable(goodSuffixTable, "Good Suffix Table");
}

void boyerMooreSearch(const std::string &text, const std::string &pattern) {
    if(pattern.empty() || pattern.length() > text.length()) return;

    std::vector<int> badCharTable(256);
    std::vector<int> goodSuffixTable;

    buildBadCharTable(pattern, badCharTable);
    buildGoodSuffixTable(pattern, goodSuffixTable);

    int n = text.length();
    int m = pattern.length();
    int i = 0;

    while(i <= n - m) {
        int j = m - 1;
        while(j >= 0 && text[i + j] == pattern[j]) {
            j--;
        }
        if(j < 0) {
            std::cout << "Boyer-Moore: Pattern found at index " << i << std::endl;
            i += (i + m < n) ? goodSuffixTable[0] : 1;
        }
        else{
            i += std::max(1, j - badCharTable[static_cast<unsigned char>(text[i + j])]);
        }
    }
}

void buildPrefixTable(const std::string &pattern, std::vector<int> &prefixTable) {
    int m = pattern.length();
    prefixTable.resize(m, 0);

    int j = 0;
    for(int i = 1; i < m; i++) {
        while(j > 0 && pattern[i] != pattern[j]) {
            j = prefixTable[j - 1];
        }

        if(pattern[i] == pattern[j]) {
            j++;
        }
        prefixTable[i] = j;
    }
    printTable(prefixTable, "Prefix Table");
}

void kmpSearch(const std::string &text, const std::string &pattern) {
    if(pattern.empty() || pattern.length() > text.length()) return;

    std::vector<int> prefixTable;
    buildPrefixTable(pattern, prefixTable);

    int n = text.length(), m = pattern.length();
    int i = 0, j = 0;

    while(i < n) {
        if(text[i] == pattern[j]) {
            i++;
            j++;
            if(j == m) {
                std::cout << "KMP: Pattern found at index " << i - m << std::endl;
                j = prefixTable[j - 1];
            }
        }
        else{
            if(j != 0) {
                j = prefixTable[j - 1];
            }
            else{
                i++;
            }
        }
    }
}

int main() {
    std::string text = "findingneedleinneedinahaystack";
    std::string pattern = "needle";

    std::cout << "Boyer-Moore Algorithm:" << std::endl;
    boyerMooreSearch(text, pattern);

    std::cout << std::endl << "Knuth-Morris-Pratt (KMP) Algorithm:" << std::endl;
    kmpSearch(text, pattern);

    return 0;
}