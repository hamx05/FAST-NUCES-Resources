#include <iostream>
#include <cstring>

void findPattern(char *text, char *pattern) {
   int n = strlen(text), m = strlen(pattern);
   for (int i = 0; i <= n - m; i++) {
       int j;
       for (j = 0; j < m; j++) {
           if (text[i + j] != pattern[j]) break;
       }
       if (j == m) std::cout << "Pattern Found at Index " << i << std::endl;
   }
}

int main() {
   char text[] = "UMEKATUMER";
   char pattern[] = "KAT";
   findPattern(text, pattern);
   return 0;
}