#include <iostream>

int **buildAdjacencyList(int vertices, int edges, int edgeList[][2]) {
    int **list = new int *[vertices];
    for(int i = 0; i < vertices; i++) {
        list[i] = new int[vertices]();
    }

    for(int i = 0; i < edges; i++) {
        int u = edgeList[i][0], v = edgeList[i][1];
        list[u][v] = 1;
        list[v][u] = 1;
    }

    return list;
}

int main() {
    int vertices = 6, edges = 8;
    int edgeList[][2] = {{0, 5}, {0, 4}, {1, 4}, {1, 2}, {1, 3}, {2, 3}, {3, 4}, {4, 5}};

    int **adjacencyList = buildAdjacencyList(vertices, edges, edgeList);

    for(int i = 0; i < vertices; i++) {
        std::cout << i << ": ";
        for (int j = 0; j < vertices; j++) {
            if (adjacencyList[i][j]) {
                std::cout << j << " ";
            }
        }
        std::cout << std::endl;
    }

    for(int i = 0; i < vertices; i++) {
        delete[] adjacencyList[i];
    }
    delete[] adjacencyList;

    return 0;
}