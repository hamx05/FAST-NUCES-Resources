#include <iostream>
using namespace std;

class User {
    protected:
        string userName;
        string email;
    
    public:
        User () {
            userName = "Hammad";
            email = "hammad968@gmail.com";
        }
        friend class Message;
};

class Message {
    public:
        void sendMsg (User &user) {
            cout<< "Message sent from " << user.userName << " and their email is: " << user.email << endl;
        }
};

int main() {
    
    User U1;
    Message M1;
    M1.sendMsg(U1);
    
    // We can access the private members of User class from Member class by making Member a friend clsas of User

}