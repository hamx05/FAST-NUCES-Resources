#include <iostream>
#include <vector>
using namespace std;

class Vehicle {
    protected:
        string name;
        string companyName;
        int price;

    public:
        Vehicle () {}
        Vehicle (string n, string cn, int p) {
            name = n;
            companyName = cn;
            price = p;
        }
};

class Cars : public Vehicle {
    protected:
        string model;
        string year;
        
    public:
        Cars () {} 
        Cars (string n, string cn, int p, string m, string y) : Vehicle (n, cn, p) {
            model = m;
            year = y;
        }
};

class Motorcycles : virtual public Vehicle {
    protected:
        string engine;
        string size;
        string color;
        string motor;
        vector <string> rentedMotorcycles;
        int MotorcycleRentFee=10000;

    public:
        Motorcycles () {}
        Motorcycles (string n, string cn, int p, string eng, string sz, string cl, string mot) : Vehicle (n, cn, p) {
            engine = eng;
            size = sz;
            color = cl;
            motor = mot;
        }
};

class Bicycles : virtual public Vehicle {
    protected:
        string engine;
        string size;
        string color;
        string seat;
        vector <string> rentedBicycles;
        int BicycleRentFee=5000;
    public:
        Bicycles () {}
        Bicycles (string n, string cn, int p, string eng, string sz, string cl, string st) : Vehicle (n, cn, p) {
            engine = eng;
            size = sz;
            color = cl;
            seat = st;
        }

};

class  Electric : public Motorcycles, public Bicycles {
    protected:
        string batteryCapacity;
        int ElectricMotorcycleRentFee = MotorcycleRentFee + 3000;
        int ElectricBicycleRentFee = BicycleRentFee + 2000;
    public:
        Electric () {}
        Electric (string n, string cn, int p, string eng, string sz, string cl, string mot, string st, int bc) : 
        Motorcycles (n, cn, p, eng, sz, cl, mot),
        Bicycles (n, cn, p, eng, sz, cl, st) {
            batteryCapacity = bc;
        }

        void rentElectric () {
            int choice1;
            char choice2;

            cout<<"1. Electric Motorcycle (Rent Rs "<<ElectricMotorcycleRentFee << ")\n2. Electric Bicycle (Rent Rs "<<ElectricBicycleRentFee << ")\nChoose which vehicle do you want rent? (1/2): " << endl;
            cin>>choice1;

            if (choice1==1) {
                cout<<"You have chosen to rent an Electric Motorcycle for Rs " << ElectricMotorcycleRentFee << endl;
                cout<<"Enter Y to confirm the purchase: " << endl;
                cin>>choice2;
                    if (choice2=='Y' || choice2=='y') {
                        cout<<"You have successfully rented an electric motorcycle for Rs " << ElectricMotorcycleRentFee << endl;
                        rentedMotorcycles.push_back("Electric Motorcycle");
                    }
                    else {
                        cout<<"Invalid Input. Purchase confirmation failed." << endl;
                    }

            }
            else if (choice1==2) {
                cout<<"You have chosen to rent an Electric Bicycle for Rs " << ElectricBicycleRentFee << endl; 
                cout<<"Press Y to confirm the purchase: " << endl;
                cin>>choice2;
                if (choice2=='Y' || choice2=='y') {
                        cout<<"You have successfully rented an electric bicycle for Rs " << ElectricBicycleRentFee << endl;
                        rentedBicycles.push_back("Electric Bicycle");
                    }
                    else {
                        cout<<"Invalid Input. Purchase confirmation failed." << endl;
                    }
            }
            else {
                cout<<"Invalid option. Purchase failed." << endl;
            }
        }
        
};

class Gasoline : public Motorcycles, public Bicycles {
    protected:
        int gasolineCapacity;
        int GasolineMotorcycleRentFee = MotorcycleRentFee + 1500;
        int GasolineBicycleRentFee = BicycleRentFee + 1000;
    public:
        Gasoline () {}

        Gasoline (string n, string cn, int p, string eng, string sz, string cl, string mot, string st,  int gc):
        Motorcycles (n, cn, p, eng, sz, cl, mot), 
        Bicycles (n, cn, p, eng, sz, cl, st) {
            gasolineCapacity = gc;
        }

        void rentGasoline () {
            int choice1;
            char choice2;

            cout<<"1.Gasoline Motorcycle (Rent Rs "<<GasolineMotorcycleRentFee << ")\n2.Gasoline Bicycle (Rent Rs "<<GasolineBicycleRentFee << ")\nChoose which vehicle do you want rent? (1/2): " << endl;
            cin>>choice1;
            
            if (choice1==1) {
                cout<<"You have chosen to rent a Gasoline Motorcycle for Rs " << GasolineMotorcycleRentFee << endl;
                cout<<"Enter Y to confirm the purchase: " << endl;
                cin>>choice2;
                    if (choice2=='Y' || choice2=='y') {
                        cout<<"You have successfully rented a Gasoline motorcycle for Rs " << GasolineMotorcycleRentFee << endl;
                        rentedMotorcycles.push_back("Gasoline Motorcycle");
                    }
                    else {
                        cout<<"Invalid Input. Purchase confirmation failed." << endl;
                    }

            }
            else if (choice1==2) {
                cout<<"You have chosen to rent an Gasoline Bicycle for Rs " << GasolineBicycleRentFee << endl;
                cout<<"Press Y to confirm the purchase: " << endl;
                cin>>choice2;
                if (choice2=='Y' || choice2=='y') {
                        cout<<"You have successfully rented an Gasoline bicycle for Rs " << GasolineBicycleRentFee << endl;
                        rentedBicycles.push_back("Gasoline Bicycle");
                    }
                    else {
                        cout<<"Invalid Input. Purchase confirmation failed." << endl;
                    }
            }
            else {
                cout<<"Invalid option. Purchase failed." << endl;
            }
        }
};


int main () {

    // Electric (string n, string cn, int p, string eng, string sz, string cl, string mot, string st, int bc) : 
    Electric E1("CD-70", "Bionic", 150000, "Boht ala", "Medium", "Black", "heavy!", "foam", 5000);
    Gasoline G1("CD-70", "Bionic", 150000, "Boht ala", "Medium", "Black", "heavy!", "foam", 5000);
    //E1.rentElectric();
    G1.rentGasoline();
    
    




    return 0;
}
